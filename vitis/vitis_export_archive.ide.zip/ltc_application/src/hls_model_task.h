#pragma once

extern "C"{
	void hlsModelTask(void *pvParameters);
}
