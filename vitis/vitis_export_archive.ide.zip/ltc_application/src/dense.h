#pragma once

#include <stdint.h>

typedef struct {
	const float *const biases;
	const float *const weights;
	const uint16_t inFeatures;
    const uint16_t neurons;
    //uint8_t inSize;


} DenseParams_t;

void densef(const float *const input, float *const output, const DenseParams_t *const params);
void densef_mac(const float *const input, float *const output, const DenseParams_t *const params);
