#include "cfc.h"
#include "activation_tanh.h"
#include "activation_relu.h"
#include <stdlib.h>
#include <string.h>
#include "sigmoid.h"
#include "pmod.h"


void cfcf(const float t_in, const float *const sig_in, float *const output, const CfcParams_t *const params, float *const backboneBuf, float *const ff1Buf, float *const ff2Buf, float *const taBuf, float *const tbBuf){

    // call backbone1 and its activation
    densef(sig_in, backboneBuf, &(params->backbone0_sig));
    densef_mac(params->state, backboneBuf, &(params->backbone0_state));
    activation_reluf(backboneBuf, backboneBuf, params->backbone0_sig.neurons);

    // call ff1, ff2, time_a, time_b and their activations
    densef(backboneBuf, ff1Buf, &(params->ff1));
    activation_tanhf(ff1Buf, ff1Buf, params->ff1.neurons);

    densef(backboneBuf, ff2Buf, &(params->ff2));
    activation_tanhf(ff2Buf, ff2Buf, params->ff2.neurons);


    densef(backboneBuf, taBuf, &(params->time_a));


    densef(backboneBuf, tbBuf, &(params->time_b));

    // closed form solution of ltc
    for(size_t i=0; i<params->neurons; ++i){
        const float t_interp = sigmoidf((tbBuf[i]-taBuf[i]*t_in));
        const float state = ff1Buf[i] * (1.0f - t_interp) + t_interp * ff2Buf[i];
        params->state[i] = state;

        output[i] = state;
    }
}
