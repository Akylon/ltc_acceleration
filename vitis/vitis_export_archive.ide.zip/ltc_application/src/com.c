#include "com.h"

SemaphoreHandle_t xSem_start_hlsModel;
SemaphoreHandle_t xSem_start_cModel;



void init_com(){
	xSem_start_hlsModel = xSemaphoreCreateBinary();
	xSem_start_cModel = xSemaphoreCreateBinary();

	if( start_hlsModel == NULL || start_cModel == NULL )
	{
		/* There was insufficient FreeRTOS heap available for the semaphore to
		be created successfully. */
		while(true){};
	}

}

void start_hlsModel(){
	xSemaphoreGive(xSem_start_hlsModel);
}

void start_cModel(){
	xSemaphoreGive(xSem_start_cModel);
}
