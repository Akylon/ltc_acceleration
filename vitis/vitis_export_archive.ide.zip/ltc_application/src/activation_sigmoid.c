#include "sigmoid.h"
#include "activation_sigmoid.h"

void activation_sigmoidf(const float *const x, float *const y, size_t size){
    while(size>0){
        --size;
        y[size] = sigmoidf(x[size]);
    };
};

void activation_sigmoid(const double *const x, double *const y, size_t size){
    while(size>0){
        --size;
        y[size] = sigmoid(x[size]);
    };
};

/*void activation_sigmoidl(const long double *const x, long double *const y, size_t size){
    while(size>0){
        --size;
        y[size] = sigmoidl(x[size]);
    };
};*/
