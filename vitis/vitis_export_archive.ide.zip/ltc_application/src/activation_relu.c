#include "activation_relu.h"

#define RELU(X) (((X) > (0.0f)) ? (X) : (0.0f))

void activation_reluf(const float *const x, float *const y, size_t size){
    while(size>0){
        --size;
        y[size] = RELU(x[size]);
    };
};

void activation_relu(const double *const x, double *const y, size_t size){
    while(size>0){
        --size;
        y[size] = RELU(x[size]);
    };
};

void activation_relul(const long double *const x, long double *const y, size_t size){
    while(size>0){
        --size;
        y[size] = RELU(x[size]);
    };
};