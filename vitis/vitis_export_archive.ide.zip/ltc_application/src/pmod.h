#pragma once


void initialiseGPIO();
void togglePins();
void setPins();
void clearPins();
