#pragma once

extern "C"{
	void modelTask(void *pvParameters);
}
