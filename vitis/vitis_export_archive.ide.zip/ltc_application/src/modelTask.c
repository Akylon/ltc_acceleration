#include "modelTask.h"
#include "xtime_l.h"
#include "xil_printf.h"

// FreeRTOS includes
#include "FreeRTOS.h"
#include "timers.h"

// std. libraries
#include <stdio.h>

// model includes
#include "walker_relu_tanh_config.h"
#include "dense.h"
#include "cfc.h"
#include "pmod.h"
#include "com.h"

#include "../data/sig_in.h"




#define DELAY_1_SECOND		1000UL

#define SEQUENCE_LENGTH 64


CfcParams_t cfcParams = {.neurons=LTC_UNITS, .sig_size=SIGNAL_INPUTLAYER_SIZE,
						 .backbone0_sig={.biases=LTC_BACKBONE_0_SIGNALBIASES, .weights=LTC_BACKBONE_0_SIGNALWEIGHTS, .inFeatures=SIGNAL_INPUTLAYER_SIZE, .neurons=LTC_BACKBONE_0_UNITS},
						 .backbone0_state={.biases=LTC_BACKBONE_0_STATEBIASES, .weights=LTC_BACKBONE_0_STATEWEIGHTS, .inFeatures=LTC_UNITS, .neurons=LTC_BACKBONE_0_UNITS},
						 .ff1={.biases=LTC_FF1_BIASES, .weights=LTC_FF1_WEIGHTS, .inFeatures=LTC_FF1_INFEATURES, .neurons=LTC_FF1_UNITS},
						 .ff2={.biases=LTC_FF2_BIASES, .weights=LTC_FF2_WEIGHTS, .inFeatures=LTC_FF2_INFEATURES, .neurons=LTC_FF2_UNITS},
						 .time_a={.biases=LTC_TA_BIASES, .weights=LTC_TA_WEIGHTS, .inFeatures=LTC_TA_INFEATURES, .neurons=LTC_TA_UNITS},
						 .time_b={.biases=LTC_TB_BIASES, .weights=LTC_TB_WEIGHTS, .inFeatures=LTC_TB_INFEATURES, .neurons=LTC_TB_UNITS},
						 .state=LTC_STATES};

DenseParams_t denseOutparams = {.biases=DENSE_OUT_BIASES, .weights=DENSE_OUT_WEIGHTS, .inFeatures=DENSE_OUT_INFEATURES, .neurons=DENSE_OUT_UNITS};

void initialiseGPIO();
void togglePins();

void modelTask(void *pvParameters){
	const TickType_t x1second = pdMS_TO_TICKS( DELAY_1_SECOND );
	initialiseGPIO();

	while(true){
		xSemaphoreTake(xSem_start_cModel, portMAX_DELAY );
		printf("C-Model Inference\n");

		static float backboneBuf[LTC_BACKBONE_0_UNITS];
		static float ff1Buf[LTC_FF1_UNITS];
		static float ff2Buf[LTC_FF2_UNITS];
		static float taBuf[LTC_TA_UNITS];
		static float tbBuf[LTC_TB_UNITS];

		static float ltc_out[SEQUENCE_LENGTH][LTC_UNITS] = {0.0f};
		static float model_out[SEQUENCE_LENGTH][DENSE_OUT_UNITS] = {0.0f};

		// iterate through sequence
		//for(size_t i=0; i<SEQUENCE_LENGTH; ++i){

		size_t i=0;
		const float *const sig_in = sig_in_sequence[i];
		const float t_in = t_in_sequence[i][0];

		// Get Start Time
		XTime timeStamp = 0;
		XTime tStart, tStop;
		XTime_GetTime(&tStart);

		// inference
		togglePins();
		cfcf(t_in, sig_in, ltc_out[i], &cfcParams, backboneBuf, ff1Buf, ff2Buf, taBuf, tbBuf);
		densef(ltc_out[i], model_out[i], &denseOutparams);
		togglePins();

		// Stop Time and TimeStamp calculation
		XTime_GetTime(&tStop);
		timeStamp = tStop-tStart;

		// Print
		/*for(size_t j=0; j<LTC_UNITS; ++j){
			printf("ltc_out[%li][%li] = %#x\n", i, j, *(uint32_t*)(ltc_out[i]+j));
		}*/
		for(size_t j=0; j<DENSE_OUT_UNITS; ++j){
			char strBuf[64] = {0};
			snprintf(strBuf, 64, "model_out[%li][%li] = %f\n", i, j, model_out[i][j]);
			xil_printf(strBuf);
		}

		//}

		// Calculate Execution Time
		double execTime = (double)timeStamp / (double)COUNTS_PER_SECOND;

		char strBuf[64] = {0};
		snprintf(strBuf, 64, "Execution time = %fms\n", execTime*1000.0f);
		xil_printf(strBuf);

		xil_printf("Finished C-Model inference\n\n");

		vTaskDelay(x1second);
		start_hlsModel();
	}

}

