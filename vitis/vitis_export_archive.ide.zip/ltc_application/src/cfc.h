#pragma once

#include <stdint.h>
#include "dense.h"

typedef struct {
    const uint16_t neurons;
    //uint8_t inSize;
    const uint16_t sig_size;
    const DenseParams_t backbone0_sig; // must have the same number of neurons as backbone1_state
    const DenseParams_t backbone0_state; // must have the same number of neurons as backbone1_sig
    const DenseParams_t ff1;
    const DenseParams_t ff2;
    const DenseParams_t time_a;
    const DenseParams_t time_b;
    float *const state;
} CfcParams_t;

void cfcf(const float t_in, const float *const sig_in, float *const output, const CfcParams_t *const params, float *const backboneBuf, float *const ff1Buf, float *const ff2Buf, float *const taBuf, float *const tbBuf);

