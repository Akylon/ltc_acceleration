#include "hls_model_task.h"
#include "xparameters.h"
#include "pmod.h"
#include "xtime_l.h"

// FreeRTOS includes
#include "FreeRTOS.h"
#include "timers.h"
#include "task.h"

// std. libraries
#include <stdio.h>

// model includes
#include "../data/sig_in.h"
#include "xmodel.h"
#include "com.h"


#define DELAY_1_SECOND		1000UL

#define SEQUENCE_LENGTH 64
#define LTC_UNITS 64
#define DENSE_OUT_UNITS 17

#define SIGNAL_INPUTLAYER_SIZE 17

void hlsModelTask(void *pvParameters){
	const TickType_t x1second = pdMS_TO_TICKS( DELAY_1_SECOND );

	// initialize model
	XModel model;
	if(XModel_Initialize(&model, XPAR_MODEL_0_DEVICE_ID) != XST_SUCCESS){
		printf("hls_model initialization failed!");
		while(true){};
	}
	XModel_DisableAutoRestart(&model);


	// prepare input data
	XModel_Signalin_reg sigIn;
	u32 timeIn;
	XModel_Output_reg output;

	// quantise signal
	for(size_t i=0; i<SIGNAL_INPUTLAYER_SIZE; ++i){
		float scale = 8;
		float sig = sig_in_sequence[0][i];
		uint8_t *const sigInPtr  = (uint8_t*)&(sigIn.word_0);
		sigInPtr[i] = (uint8_t)(sig*scale);

		timeIn = (uint8_t)t_in_sequence[0][0];
	}



	// setup interrupt
	uint8_t interruptStatus = XModel_InterruptGetStatus(&model);
	XModel_InterruptClear(&model, interruptStatus); //clear ap_done interrupt and ap_ready interrupt
	//XModel_InterruptEnable(&model, 0b1); // enable ap_done interrupt
	//XModel_InterruptGlobalEnable(&model); // enable gloabl interrupt


	initialiseGPIO();



	while(true){
		xSemaphoreTake(xSem_start_hlsModel, portMAX_DELAY );
		printf("HLS-Model Inference\n");
		// wait until idle
		while(! XModel_IsIdle(&model)){
		}

		// pass input data
		XModel_Set_signalIn_reg(&model, sigIn);
		XModel_Set_timeIn_reg(&model, timeIn);

		interruptStatus = XModel_InterruptGetStatus(&model);
		XModel_InterruptClear(&model, interruptStatus);

		XModel_Start(&model);

		// Get Start Time
		XTime timeStamp = 0;
		XTime tStart, tStop;
		XTime_GetTime(&tStart);

		// Toggle pin for oscilloscope measurement
		togglePins();

		// wait until done. Currently polling is used.
		while(! XModel_IsDone(&model)){
			//vTaskDelay( x1second );
		}
		// Toggle pin for oscilloscope measurement
		togglePins();

		// Stop Time and TimeStamp calculation
		XTime_GetTime(&tStop);
		timeStamp = tStop-tStart;

		// read out results
		output = XModel_Get_output_reg(&model);

		int8_t *outPtr = (int8_t*)&(output.word_0);
		for(size_t i=0; i<17; ++i){
			const double outscale = 0.125; // outshift is -3
			const double out = (double)outPtr[i]*outscale;

			printf("model_out[%li] = %f\n", i, out);
		}

		// Calculate Execution Time
		double execTime = (double)timeStamp / (double)COUNTS_PER_SECOND;
		printf("Execution time =  = %fus\n", execTime*1000000.0f);

		printf("Finished HLS-Model inference\n\n");

		vTaskDelay(x1second);
		start_cModel();
	}
}


