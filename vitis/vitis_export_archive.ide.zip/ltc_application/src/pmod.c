#include "pmod.h"

#include "xparameters.h"
#include "xgpio.h"

static XGpio plGpio;
static uint32_t pinStates = 0x0000;

#define GPIO_CHANNEL 1

void initialiseGPIO(){
	if(XGpio_Initialize(&plGpio, XPAR_GPIO_0_DEVICE_ID) !=XST_SUCCESS){
		while(true){};
	}
}

void togglePins(){
	const uint32_t pinMask = 0x0001;


	pinStates = ~pinStates;
	XGpio_DiscreteWrite(&plGpio, GPIO_CHANNEL, pinStates&pinMask);
}

void setPins(){
	const uint32_t pinMask = 0x0001;
	pinStates = 0xFFFFFFFF;
	XGpio_DiscreteWrite(&plGpio, GPIO_CHANNEL, pinStates&pinMask);
}

void clearPins(){
	const uint32_t pinMask = 0x0001;
	pinStates = 0x0;
	XGpio_DiscreteWrite(&plGpio, GPIO_CHANNEL, pinStates&pinMask);
}
