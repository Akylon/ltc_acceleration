#include "dense.h"
#include "stddef.h"

void densef(const float *const input, float *const output, const DenseParams_t *const params){
    for(size_t neuron=0; neuron<params->neurons; ++neuron){
        float sum = 0;
        for(size_t feature=0; feature<params->inFeatures; ++feature){
            sum += input[feature] * params->weights[feature + neuron*params->inFeatures];
        }
        output[neuron] = sum + params->biases[neuron];
    }
}


void densef_mac(const float *const input, float *const output, const DenseParams_t *const params){
    for(size_t neuron=0; neuron<params->neurons; ++neuron){
        float sum = 0;
        for(size_t feature=0; feature<params->inFeatures; ++feature){
            sum += input[feature] * params->weights[feature + neuron*params->inFeatures];
        }
        output[neuron] += sum + params->biases[neuron];
    }
}
