#pragma once

#include <stdio.h>

void activation_sigmoidf(const float *const x, float *const y, size_t size);
void activation_sigmoid(const double *const x, double *const y, size_t size);
//void activation_sigmoidl(const long double *const x, long double *const y, size_t size);

