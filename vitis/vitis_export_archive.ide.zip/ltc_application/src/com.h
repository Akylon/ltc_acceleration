#include <FreeRTOS.h>
#include <semphr.h>

extern SemaphoreHandle_t xSem_start_hlsModel;
extern SemaphoreHandle_t xSem_start_cModel;


void init_com();
void start_hlsModel();
void start_cModel();
