/*
    Copyright (C) 2017 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
    Copyright (c) 2012 - 2022 Xilinx, Inc. All Rights Reserved.
	SPDX-License-Identifier: MIT


    http://www.FreeRTOS.org
    http://aws.amazon.com/freertos


    1 tab == 4 spaces!
*/

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
/* Xilinx includes. */
#include "xil_printf.h"
#include "xparameters.h"


// My includes
#include "modelTask.h"
#include "hls_model_task.h"
#include "com.h"


#define TIMER_ID	1
#define DELAY_10_SECONDS	10000UL
#define DELAY_1_SECOND		1000UL
#define TIMER_CHECK_THRESHOLD	9

/*-----------------------------------------------------------*/

/* The queue used by the Tx and Rx tasks, as described at the top of this
file. */
static TaskHandle_t xModelTask;
static TaskHandle_t xHlsModelTask;
char HWstring[15] = "Hello World";
long RxtaskCntr = 0;

#if (configSUPPORT_STATIC_ALLOCATION == 1)
#define QUEUE_BUFFER_SIZE		100

uint8_t ucQueueStorageArea[ QUEUE_BUFFER_SIZE ];
StackType_t xStack1[ configMINIMAL_STACK_SIZE ];
StackType_t xStack2[ configMINIMAL_STACK_SIZE ];
StaticTask_t xTxBuffer,xRxBuffer;
StaticTimer_t xTimerBuffer;
static StaticQueue_t xStaticQueue;
#endif

int main( void )
{
	xil_printf( "Setting up tasks\r\n" );


	xTaskCreate( modelTask,
				 ( const char * ) "modelTask",
				 512,
				 NULL,
				 tskIDLE_PRIORITY + 2,
				 &xModelTask );

	xTaskCreate( hlsModelTask,
				 ( const char * ) "hlsModelTask",
				 512,
				 NULL,
				 tskIDLE_PRIORITY + 2,
				 &xHlsModelTask );



	// Initialise communication signals and set start_cModel flag
	init_com();
	start_cModel();


	/* Start the tasks and timer running. */
	xil_printf( "Starting Scheduler\r\n" );
	vTaskStartScheduler();

	for( ;; );
}


