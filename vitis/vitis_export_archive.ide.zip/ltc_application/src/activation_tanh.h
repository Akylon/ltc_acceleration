#pragma once

#include <stdio.h>

void activation_tanhf(const float *const x, float *const y, size_t size);
void activation_tanh(const double *const x, double *const y, size_t size);
//void activation_tanhl(const long double *const x, long double *const y, size_t size);
